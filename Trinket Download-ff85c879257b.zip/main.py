print("Hi, I am your instructur T Sam. I will help you become a singer.")

print("\nAnswer three of the following questions so that I can understand your music taste.")

num = 0
num1 = 0
num2 = 0

print("Why do you listen to music?\na. Just for fun, I like it\nb. Mostly for emotional backup\nc. For work or exercise")
chsn = input("Enter the letter of your answer: ").lower()
if chsn == "a":
     num += 1
elif chsn == "b":
    num1 += 1
else:
    num2 += 1

print("What kind of music do you enjoy?\na. Upbeat and energetic\nb. A mixture of all\nc. Emotional and deep")
chsn = input("Enter the letter of your answer: ").lower()
if chsn == "a":
     num += 1
elif chsn == "b":
    num1 += 1
else:
    num2 += 1

print("What kind of song do you listen to?\na. K-pop or J-pop\nb. Pop\nc. Folk")
chsn = input("Enter the letter of your answer: ").lower()
if chsn == "a":
     num += 1
elif chsn == "b":
    num1 += 1
else:
    num2 += 1

print("\nLET'S KNOW WHAT KIND OF SONG YOU WILL SING")

if num > num1 and num > num2:
    print("You will sing energetic and pop songs that make everyone's mood better and are perfect for parties.")
elif num1 > num and num1 > num2:
    print("You will sing soft and normal-beat songs, suitable as background music.")
else:
    print("You will sing folklore and deep, meaningful songs full of emotion.")

fame = 0
mid = 0
fail = 0




print("\nNow it's time to see your taste in settings for the stage")
print("\nChoose a place\na. Stadium or field\nb. In a school or office auditorium\nc. In a restaurant")
chsn = input("Enter the letter of your answer: ").lower()

fame = 0
fail = 0
mid = 0

if chsn == "a":
    print("\nEVERYONE LOVED YOUR CONCERT")
    fame += 1
elif chsn == "b":
    print("\nYOU DISTRACTED PEOPLE AND THEY SENT YOU TO JAIL")
    fail += 1
else:
    print("\nOk, BUT YOU GOT ONLY A VERY FEW PEOPLE")
    mid += 1

print("\nNow it's time to know the price of your ticket for a 1-hour concert")
print("\nChoose the amount\na. 400 taka\nb. 4000 taka\nc. 900 taka")
chsn = input("Enter the letter of your answer: ").lower()

if chsn == "a":
    print("\nEVERYONE WENT TO YOUR CONCERT")
    fame += 1
elif chsn == "b":
    print("\nNOBODY CAME")
    fail += 1
else:
    print("\nOk, BUT ONLY A VERY FEW PEOPLE")
    mid += 1

print("\nTIME TO SEE YOUR SUCCESS")

if fail == 1 or fail == 2:
    print("YOU FAILED TO BECOME A POPULAR SINGER")
elif fame == 1 or mid == 1:
    print("YOU COULD'VE DONE BETTER")
elif mid == 2:
    print("YOU ARE BARELY SURVIVING")
else:
    print("CONGRATULATIONS, YOU ARE A POPULAR SINGER NOW")

