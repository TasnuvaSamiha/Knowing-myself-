print("KNOWING MYSELF: Do you want to know if you are an introvert, extrovert, or ambivert? Then answer these ten questions.\n")

ext = 0
intr = 0
amb = 0

# Question 1
print(1, ") How would you like to spend your time when you are bored?")
print("a) I like to follow my hobbies or do something alone \nb) I sometimes do something alone and sometimes I would like to have a small chat with someone\nc) A small chat with someone is all I need.\n")
cn = input("Enter the letter of your answer:\n").lower()  # Use .lower() with parentheses

if cn == "a":
    intr += 1
elif cn == "b":
    amb += 1
else:
    ext += 1

# Question 2
print(2, ") When attending social gatherings, do you tend to initiate conversations or wait for others to approach you?")
print("a) I would rather not talk unless someone approaches\nb) It depends on the person, if known I talk, if not I would wait\nc) I would like to approach people\n")
cn = input("Enter the letter of your answer:\n").lower()

if cn == "a":
    intr += 1
elif cn == "b":
    amb += 1
else:
    ext += 1

# Question 3
print(3, ") Do you find yourself drained or energized after spending time in large groups of people?")
print("a) Totally drained\nb) Depends on the group\nc) It's okay. I feel energized\n")
cn = input("Enter the letter of your answer:\n").lower()

if cn == "a":
    intr += 1
elif cn == "b":
    amb += 1
else:
    ext += 1

# Question 4
print(4, ") How do you feel about attending events where you don't know many people?")
print("a) I tend to stay at home and prefer not to go\nb) It depends, there MUST be one person I know\nc) I won't miss any event\n")
cn = input("Enter the letter of your answer:\n").lower()

if cn == "a":
    intr += 1
elif cn == "b":
    amb += 1
else:
    ext += 1

# Question 5
print(5, ") What do you do on weekends?")
print("a) Stay home and do things I like to do myself\nb) Sometimes enjoy alone sometimes with people\nc) I would love to spend time socializing\n")
cn = input("Enter the letter of your answer:\n").lower()

if cn == "a":
    intr += 1
elif cn == "b":
    amb += 1
else:
    ext += 1

# Question 6
print(6, ") Do you enjoy working in groups or alone?")
print("a) Working alone is the best\nb) Sometimes alone, sometimes with people\nc) Group works are more preferred by me\n")
cn = input("Enter the letter of your answer:\n").lower()

if cn == "a":
    intr += 1
elif cn == "b":
    amb += 1
else:
    ext += 1

# Question 7
print(7, ") How do you like a small talk?")
print("a) I don't enjoy it and avoid\nb) If I know the person, I love it\nc) I would love to\n")
cn = input("Enter the letter of your answer:\n").lower()

if cn == "a":
    intr += 1
elif cn == "b":
    amb += 1
else:
    ext += 1

# Question 8
print(8, ") Do you feel any problem talking to a random person for an order or anything?")
print("a) I struggle badly\nb) If it's way too necessary, I am with it\nc) No problem\n")
cn = input("Enter the letter of your answer:\n").lower()

if cn == "a":
    intr += 1
elif cn == "b":
    amb += 1
else:
    ext += 1

# Question 9
print(9, ") Anywhere, do you like to be the center of attention?")
print("a) I hate it from the depths of me\nb) It's okay, I will manage\nc) I like it\n")
cn = input("Enter the letter of your answer:\n").lower()

if cn == "a":
    intr += 1
elif cn == "b":
    amb += 1
else:
    ext += 1

# Question 10
print(10, ") How much do you talk?")
print("a) I don't like it that much\nb) It's okay as long as I know the person I talk to\nc) Most of the time\n")
cn = input("Enter the letter of your answer:\n").lower()

if cn == "a":
    intr += 1
elif cn == "b":
    amb += 1
else:
    ext += 1

# Final result
if intr > ext and intr > amb:
    print("--You are an INTROVERT--")
elif ext > intr and ext > amb:
    print("--You are an EXTROVERT--")
else:
    print("--You are an AMBIVERT--")
